"""Reachable frontier exploration study."""
